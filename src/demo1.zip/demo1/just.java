package demo1;

public class just {

public static void main(String[] args) {
 int n=4;
 int i,j;
 
for(i=1; i<=n; i++)
{
 j=1;

while(j<=(n-i))
{
 System.out.print("  ");
 j++;
}
//loop 1 
 j=1;
 while(j<(i+1))
 {
  System.out.print(j+" ");
  j++;
 }
 //loop 2
 j=i-1;
 while( j>=1)
 {
  System.out.print(j+" ");
  j--;
 }
 System.out.println("");
} 
}
}